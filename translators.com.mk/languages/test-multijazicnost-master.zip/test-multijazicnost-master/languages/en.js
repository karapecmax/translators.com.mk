var EN_TRANSLATION = {
    "text1" : "text One",
    "text2" : "text Two"
};
