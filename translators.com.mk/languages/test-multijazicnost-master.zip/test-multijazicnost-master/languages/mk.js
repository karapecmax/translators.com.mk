var MK_TRANSLATION = {
    "text1" : "Текст 1",
    "text2" : "Текст 2"
};

