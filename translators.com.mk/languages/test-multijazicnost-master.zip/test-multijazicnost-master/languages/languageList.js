var LanguageList = {
    "EN" : "English",
    "MK" : "Macedonian",
};
